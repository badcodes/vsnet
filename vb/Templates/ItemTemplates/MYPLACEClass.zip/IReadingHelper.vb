Namespace MYPLACE
	Public Class MYPLACEClass

	End Class
End Namespace
